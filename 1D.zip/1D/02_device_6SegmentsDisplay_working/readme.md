# Random Number Generator

This module generates random number between 0 to 255 and display it on the 7 segment. 

Upon running, press `io_button[0]` to start generating.

You can change the value of `CLOCK_DIVIDER` in `alchitry_top.luc` to allow the module to generate the number slower/faster. 
